// 网络请求的例子
import Request from '../utils/request'
import Store from '../store/'

export default async (params) => {
  try {
    // 请求开始，开始loading
    // Store.dispatch('requestLoading', true)
    let data = await Request.get({
      url: 'open/vpaishe/index.html'
    })
    // 请求结束后停止loading
    // Store.dispatch('requestLoading', false)
    if (+data.ret === 0) {
      // 如果成功即使没有数据也应该是个空数组
      return Promise.resolve(data)
    } else {
      window.alert(data.msg.toLowerCase())
      // 如果请求接口报错就处理
      Store.dispatch('requestFail', data)
      throw new Error(data)
    }
  } catch (err) {
    return Promise.reject(err)
  }
}
