<template>
  <div class="contact-us-page">
    <header-white></header-white>
    <div class="contact-us-box">
      <img class="gywm-banner" v-show="titleBar === 1" src="../../assets/contact_us/gywm-banner.jpg" alt="关于我们">
      <img class="gywm-banner" v-show="titleBar === 3" src="../../assets/contact_us/lxwm-banner.jpg" alt="联系我们">
      <div class="contact-us-content">
        <div class="btn-group">
          <button :class="{'title-bar-bg': titleBar === 1}" @click="selectTitle(1)">关于我们</button>
          <button>加入我们</button>
          <button :class="{'title-bar-bg': titleBar === 3}" @click="selectTitle(3)">联系我们</button>
        </div>
        <div class="title-des">
          <img class="v-logo" src="../../assets/contact_us/gywm-logo.png" alt="logo">
          <p class="we-show" v-show="titleBar === 1">
            微拍摄成立于2015年，是新浪微博旗下专注于商业视频解决方案的服务平台，<br><br>
            微拍摄专注于为企业客户提供低成本高质量的标准化视频制和发行服务。<br><br>
            微拍摄颠覆了传统影视广告行业的诸多弊端，在保证视频质量的同时，为企业客户节约了大量的时间，资金成本。
          </p>
          <p class="we-phone" v-show="titleBar === 3">
            <span>商务合作：</span>business@vpaishe.com<br><br>
            <span>客户服务：</span>ae@vpaishe.com<br><br>
            <span>咨询电话：</span>4008008800<br><br>
            <span>地&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;址：</span>北京市朝阳区竞园艺术中心36C
          </p>
        </div>
        <div class="item-box" v-show="titleBar === 1">
          <div class="item">
            <img src="../../assets/contact_us/ys-1.png" alt="免费无限创意">
            <p class="item-h4">免费无限创意</p>
            <p class="item-line"></p>
            <p class="item-des">10+万资深策划编辑创意提供</p>
          </div>
          <div class="item">
            <img src="../../assets/contact_us/ys-2.png" alt="资深制作团队">
            <p class="item-h4">资深制作团队</p>
            <p class="item-line"></p>
            <p class="item-des">6000+专业制作团队优中选优</p>
          </div>
          <div class="item">
            <img src="../../assets/contact_us/ys-1.png" alt="高品质保障">
            <p class="item-h4">高品质保障</p>
            <p class="item-line"></p>
            <p class="item-des">低成本高品质保障费用低于行业50%</p>
          </div>
          <div class="item">
            <img src="../../assets/contact_us/ys-1.png" alt="一对一服务">
            <p class="item-h4">一对一服务</p>
            <p class="item-line"></p>
            <p class="item-des">视频管家一对一现场监制</p>
          </div>
        </div>
        <div v-show="titleBar === 1">
          <img class="step" src="../../assets/contact_us/gywm-lc.png">
        </div>
      </div>
    </div>
    <footer-vue></footer-vue>
  </div>
</template>

<script>
  import HeaderWhite from '../layout/headerWhite'
  import FooterVue from '../layout/footer'

  export default {
    name: 'home',
    components: {
      HeaderWhite,
      FooterVue
    },
    data () {
      return {
        titleBar: 1
      }
    },
    created () {
    },
    mounted () {
    },
    methods: {
      selectTitle (num) {
        this.titleBar = num
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .contact-us-page {
    width: 100%;
    .contact-us-box {
      margin-top: 62px;
      .contact-us-content {
        height: 789px;
      }
      background-color: #f3f3f3;
      overflow: hidden;
      .gywm-banner {
        width: 100%;
        height: 100%;
      }
      .title-des {
        margin: 0 auto;
        width: 930px;
        height: 198px;;
        background-color: #fff;
        display: flex;
        justify-content: center;
        align-items: center;

        .v-logo {
          width: 75px;
          height: 30px;
          margin-right: 80px;
        }
        .we-show {
          text-align: left;
          font-size: 13px;
          color: #4e4e4e;
        }
        .we-phone {
          text-align: left;
          font-size: 13px;
          color: #444;
          span {
            margin-right: 20px;
            font-size: 14px;
            color: #444;
          }
        }
      }
      .item-box {
        margin: 20px auto;
        width: 930px;
        height: 203px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        .item {
          display: flex;
          justify-content: center;
          flex-wrap: wrap;
          background-color: #fff;
          width: 223px;
          height: 202px;

          img {
            margin-top: 30px;
            margin-bottom: 15px;
            width: 56px;
            height: 56px;
          }
          p {
            margin: 0;
            height: 15px;
            line-height: 15px;
          }
          .item-h4 {
            width: 220px;
            color: #333;
            font-size: 13px;
          }
          .item-line {
            margin-top: -5px;
            width: 30px;
            background-color: #fd1212;
            height: 1px; 
          }
          .item-des {
            width: 220px;
            color: #6b6b6b;
            font-size: 12px;
            margin-bottom: 20px;
          }
        }
      }
      .step {
        margin-top: 80px;
        margin-bottom: 80px;
        width: 930px;
        height: 54px;
      }
      .btn-group {
        padding: 50px;
        button {
          margin: 0 8px;
          outline: 0;
          background-color: #fff;
          border: 0;
          width: 120px;
          height: 28px;
          border-radius: 14px;
          color: #484848;
        }
        .title-bar-bg {
          color: #fff;
          background-color: #fd1212;
        }
      }
    }
  }
</style>
