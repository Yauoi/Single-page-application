<template>
  <div class="sign-component">
    <div class="sign-box">
      <div class="phone">
          <input type="text" placeholder="请输入手机号" v-model="phone">
          <button @click="join">立即预约</button>
        </div>
        <div class="code">
          <input type="text" placeholder="请输入验证码" v-model="code">
          <button :class="{'btn-bg': timeRun}" @click="getCode">{{ codeDes }}</button>
        </div>
      </div>
    </div>   
</template>

<script>
  export default {
    name: 'sign',
    data () {
      return {
        code: '',
        phone: '',
        timeRun: false,
        codeDes: '获取验证码',
        isrequest: false
      }
    },
    methods: {
      join () {
        if (!this.code.trim() || !this.phone.trim()) {
          window.alert('不能为空')
          return false
        }
        let params = {
          phone: this.phone.trim(),
          code: +this.code.trim()
        }
        // 请求
        this.$store.dispatch('joinAction', params)
      },
      getCode () {
        if (!this.checkPhone(this.phone.trim())) {
          return
        }
        // 正在倒计时就不让用户继续获取验证码
        if (this.timeRun) {
          return
        }
        this.$store.dispatch('getCodeAction', this.phone.trim())
        this.setTime()
      },
      checkPhone (phoneNum) {
        if (!(/^1(3|4|5|7|8)\d{9}$/.test(phoneNum))) {
          window.alert('手机号码有误，请重填')
          return false
        }
        return true
      },
      // 验证码倒计时
      setTime () {
        let sed = 120
        this.timeRun = true
        let setI = setInterval(() => {
          if (sed < 0) {
            this.codeDes = '获取验证码'
            this.timeRun = false
            clearInterval(setI)
            return
          }
          this.codeDes = `已发送 (${sed--})`
        }, 1000)
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .sign-component {
    width: 380px;
    height: 160px;
    background-color: rgba(0,0,0,0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    .sign-box {
      width: 320px;
      height: 160px;
      display: flex;
      justify-content: row;
      flex-wrap: wrap;
      align-content: space-around;
    }
    padding: 20px;
    .phone {
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 0;
      input {
        padding-left: 5px;
        line-height: 40px;
        font-size: 13px;
        width: 220px;
        height: 40px;
        margin: 0;
        border: 0;
        outline: 0;
      }
      button {
        line-height: 40px;
        font-size: 13px;
        width: 100px;
        height: 40px;
        outline: 0;
        background-color: #fd1212;
        border: 0;
        color: #fff;
        margin: 0;
      }
    }
    .code {
      margin-top: -20px;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 0;
      input {
        padding-left: 5px;
        font-size: 13px;
        width: 120px;
        height: 40px;
        margin: 0;
        border: 0;
        outline: 0;
      }
      .btn-bg {
        background-color: #9c9c9c;
      }
      button {
        font-size: 13px;
        width: 100px;
        height: 40px;
        outline: 0;
        background-color: #fd1212;
        border: 0;
        color: #fff;
        margin: 0;
      }
    }
    
    .title {
      display: flex;
      justify-content: center;
      align-items: center;
      p {
        margin: 0;
      }
      .titel-item {
        margin: 0 30px;
        .line-bottom {
          border-bottom: 2px solid #fd1212;
        }
      }
    }
  }
</style>