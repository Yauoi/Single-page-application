<template>
  <div class="service-page">
    <header-white class="header-position"></header-white>
    <div class="process-box">
      <img class="title-logo" src="../../assets/service/1111.png" alt="我们对作品力求完美">
      <div class="process-parent">
        <div class="process-left">
          <div class="process-item-1">
            <h3 class="process-left-h3">方案策划</h3>
            <p class="process-left-p-cn">
              明确需求后，将从与我们长期合作的6000+资深策划编剧中<br>筛选最符合需求的创作团队完成策划提案。
            </p>
            <p class="process-left-p-en">
              After clarifying the requirements, we will be working <br>with the senior pianning screenwriter who <br>has been working with us for
            </p>
          </div>
          <div class="process-item-2">
            <h3 class="process-left-h3">拍摄剪辑</h3>
            <p class="process-left-p-cn">
              微拍摄将全程监制拍摄过程，并按照最优配置完成拍摄，<br>以达到完美呈现创意方案的效果
            </p>
            <p class="process-left-p-en">
              Microfilming will process the whole  process of filming and sho
            </p>
          </div>
          <div class="process-item-3">
            <h3 class="process-left-h3">验收交片</h3>
            <p class="process-left-p-cn">
              客服满意就是我们的服务宗旨，经过您最后的验收后，将成片<br>交付给您并将费用结算给创作团队，若不满意可重新制作。
            </p>
            <p class="process-left-p-en">
              Customer service satisfaction is our service tenet. After your
            </p>
          </div>
        </div>
        <img class="process-line" src="../../assets/service/line.png" alt="line">
        <div class="process-right">
          <div class="process-item-4">
            <h3 class="process-left-h3">沟通需求</h3>
            <p class="process-left-p-cn">
              获取拍摄需求，会有项目经理第一时间与您一对一沟通，<br>全方位了解拍摄需求
            </p>
            <p class="process-left-p-en">
              To get the shooting requirements, the project manager will communicate with you<br>
              One-on-one for the first time<br>
              Fully understand the shooting requirements
            </p>
          </div>
          <div class="process-item-5">
            <h3 class="process-left-h3">商务流程</h3>
            <p class="process-left-p-cn">
              经过详细的方案创意阐述及拍摄分镜效果呈现，<br>确定制作方案后进入商务流程
            </p>
            <p class="process-left-p-en">
              Through detailed programme creative elaboration and the<br>  shooti
            </p>
          </div>
          <div class="process-item-6">
            <h3 class="process-left-h3">后期修改</h3>
            <p class="process-left-p-cn">
              完成拍摄剪辑后，将样片交付与您沟通，一起打磨<br>每一个画面细节，对作品我们力求完美
            </p>
            <p class="process-left-p-en">
              After finishing the film clip, deliver the sample <br>to you and po
            </p>
          </div>
        </div>
      </div>
    </div>
    <footer-vue></footer-vue>
  </div>
</template>

<script>
  import HeaderWhite from '../layout/headerWhite'
  import FooterVue from '../layout/footer'

  export default {
    name: 'home',
    components: {
      HeaderWhite,
      FooterVue
    },
    data () {
      return {
      }
    },
    created () {
    },
    mounted () {
    },
    methods: {
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .process-box {
    margin-top: 62px;
    background-image: url('../../assets/service/bg.jpg');
    width: 100%;
    height: 1334px;
    background-repeat: no-repeat;
    .title-logo {
      margin-top: 55px;
      width: 544px;
      height: 79px;
      margin-bottom: 50px;
    }
    .process-line {
      width: 8px;
      height: 1100px;
      margin: 0 50px;
    }
    .process-parent {
      display: flex;
      justify-content: center;
      .process-left-h3 {
        margin-top: 0;
        margin-bottom: 10px;
        color: #222;
      }
      .process-left-p-cn {
        color: #5d5d5d;
        font-size: 13px;
      }
      .process-left-p-en {
        margin-bottom: 0;
        color: #afafaf;
        font-size: 12px;
      }
      .process-left {
        text-align: right;
        margin-top: 174px;
        .process-item-1 {
          padding-top: 20px;
          padding-right: 60px;
          background-image: url('../../assets/service/2.png'), url('../../assets/service/wzbg.png');
          background-position: left bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
        .process-item-2 {
          padding-top: 20px;
          padding-right: 60px;
          margin-top: 144px;
          background-image: url('../../assets/service/4.png'), url('../../assets/service/wzbg.png');
          background-position: left bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
        .process-item-3 {
          padding-top: 20px;
          padding-right: 60px;
          margin-top: 144px;
          background-image: url('../../assets/service/6.png'), url('../../assets/service/wzbg.png');
          background-position: left bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
      }
      .process-right {
        text-align: left;
        .process-item-4 {
          padding-top: 20px;
          padding-left: 60px;
          margin-top: 25px;
          background-image: url('../../assets/service/1.png'), url('../../assets/service/kuang_03.png');
          background-position: right bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
        .process-item-5 {
          padding-top: 20px;
          padding-left: 60px;
          margin-top: 144px;
          background-image: url('../../assets/service/3.png'), url('../../assets/service/kuang_03.png');
          background-position: right bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
        .process-item-6 {
          padding-top: 20px;
          padding-left: 60px;
          margin-top: 144px;
          background-image: url('../../assets/service/5.png'), url('../../assets/service/kuang_03.png');
          background-position: right bottom, left top;
          background-size: 56px 56px, 423px 187px;
          background-repeat: no-repeat, repeat;
          height: 187px;
          width: 423px;
        }
      }
    }
  }
</style>
