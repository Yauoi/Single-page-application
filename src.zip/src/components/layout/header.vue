<template>
  <div class="header-component">
    <div v-show="logoState === 1" class="logo-fixed"><img src="../../assets/service/logoo_03.png" alt="微拍摄"></div>
    <div v-show="logoState === 0" class="logo"><img src="../../assets/logol_03.png" alt="微拍摄"></div>
    <div class="title">
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 1}" @click="changePageRouter(1)">首页</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 2}" @click="changePageRouter(2)">精选视频</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 3}" @click="changePageRouter(3)">解决方案</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 4}" @click="changePageRouter(4)">服务流程</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 5}" @click="changePageRouter(5)">联系我们</p>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapState } from 'vuex'
  export default {
    name: 'header',
    data () {
      return {
        navId: 1
      }
    },
    mounted () {
    },
    computed: mapState({
      navState: state => state.global.navState,
      logoState: state => state.global.logoState
    }),
    methods: {
      changePageRouter (num) {
        this.$store.commit('NAV_STATE', num)
        this.navId = num
        if (num === 4) {
          this.$router.push({ path: '/service_process' })
          return
        }
        if (num === 5) {
          this.$router.push({ path: '/contact_us' })
          return
        }
        let router = '/'
        this.$router.push({ path: router })
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .header-component {
    font-size: 16px;
    color: #fff;
    position: relative;
    height: 60px;
    width: 100%;
    line-height: 60px;
    .logo {
      position: absolute;
      left: 50px;
      top: 18px;
      z-index: 10;
      img {
        width: 78px;
        height: 33px;
      }
    }
    .logo-fixed {
      position: absolute;
      left: 50px;
      top: 6px;
      z-index: 10;
      img {
        width: 67px;
        height: 19px;
      }
    }
    .title {
      display: flex;
      justify-content: center;
      align-items: center;
      p {
        cursor: pointer;
        margin: 0;
      }
      .titel-item {
        margin: 0 30px;
        .line-bottom {
          border-bottom: 2px solid #fd1212;
        }
      }
    }
  }
</style>
