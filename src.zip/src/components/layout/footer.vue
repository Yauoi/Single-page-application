<template>
  <div class="footer-component">
    <div class="box-1">
      <div class="box-2">
        <div class="footer-logo">
          <img src="../../assets/footer_03.png">
        </div>
        <div class="footer-content">
          <div>
            <a>关于我们</a>
            <p><img src="../../assets/phone.png">联系电话: 400-600-3940</p>
          </div>
          <div>
            <a>联系我们</a>
            <p><img src="../../assets/letter.png">商务合作：business@vpaishe.com</p>
          </div>
          <div>
            <a>服务流程</a>
            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;客户服务：ae@vpaishe.com</p>
          </div>
          <div>
            <a>服务协议</a>
          </div>
        </div>
        <div class="footer-qr">
          <img src="../../assets/qr.png">
          <p>微拍摄公众号</p>
        </div>
      </div>
      <div class="line-bottom">
        <p>© 2017微拍摄　京ICP备14040205号-1</p>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'header',
    data () {
      return {
        navId: 1
      }
    },
    methods: {
      changePageRouter (num) {
        this.navId = num
        let router = '/'
        this.$router.push({ path: router })
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .footer-component {
    background-color: #1d1d1d;
    height: 231px;
    padding-top: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    .box-1 {
      width: 940px;
      .box-2 {
        display: flex;
        justify-content: space-between;

      }
    }
    .footer-logo {
      img {
        margin-left: 10px;
        margin-top: 40px;
        width: 84px;
        height: 38px;
      }
    }
    .footer-qr {
      img {
        width: 105px;
        height: 105px;
      }
      p {
        margin-top: 5px;
        color: #616161;
        font-size: 12px;
      }
    }
    .footer-content {
      width: 400px;
      div {
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #616161;
        font-size: 12px;
        a {
          text-align: left;
          width: 80px;
          margin-right: 60px;
        }
        img {
          margin-bottom: -2px;
          margin-right: 6px;
          width: 15px;
          height: 15px;
        }
        p {
          width: 280px;
          text-align: left;
          margin: 6px auto;
        }
        
      }
    }
    .line-bottom {
      p {
        padding-left: 10px;
        color: #616161;
        font-size: 12px;
        text-align: left;
        margin: 0;
      }
      width: 940px;
      line-height: 50px;
      height: 50px;
      border-top: 1px solid #676767;
    }
  }
</style>