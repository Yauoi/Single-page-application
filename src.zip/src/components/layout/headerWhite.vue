<template>
  <div class="header-white-component">
    <div class="logo"><img src="../../assets/service/logoo_03.png" alt="微拍摄"></div>
    <div class="title">
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 1}" @click="changePageRouter(1)">首页</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 2}" @click="changePageRouter(2)">精选视频</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 3}" @click="changePageRouter(3)">解决方案</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 4}" @click="changePageRouter(4)">服务流程</p>
      </div>
      <div class="titel-item">
        <p :class="{'line-bottom': navId === 5}" @click="changePageRouter(5)">联系我们</p>
      </div>
    </div>
    <div class="me-pricture">我要拍片</div>
  </div>
</template>

<script>
  import { mapState } from 'vuex'
  export default {
    name: 'header',
    data () {
      return {
        navId: null
      }
    },
    computed: mapState({
      navState: state => state.global.navState
    }),
    mounted () {
      this.navId = this.navState
    },
    methods: {
      changePageRouter (num) {
        this.$store.commit('NAV_STATE', num)
        this.navId = num
        if (num === 4) {
          this.$router.push({ path: '/service_process' })
          return
        }
        if (num === 5) {
          this.navId = num
          this.$router.push({ path: '/contact_us' })
          return
        }
        let router = '/'
        this.$router.push({ path: router })
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  .header-white-component {
    font-size: 16px;
    color: #333;
    position: fixed;
    top: 0;
    left: 0;
    background-color: #fff;
    height: 60px;
    width: 100%;
    line-height: 60px;
    .logo {
      position: absolute;
      left: 50px;
      top: 6px;
      z-index: 10;
      img {
        width: 67px;
        height: 19px;
      }
    }
    .me-pricture {
      color: #fd1212;
      font-size: 13px;
      position: absolute;
      right: 50px;
      top: 16px;
      z-index: 10;
      border: 1px solid #fd1212;
      border-radius: 4px;
      height: 30px;
      line-height: 30px;
      width: 150px;
    }
    .title {
      display: flex;
      justify-content: center;
      align-items: center;
      p {
        cursor: pointer;
        margin: 0;
      }
      .titel-item {
        margin: 0 30px;
        .line-bottom {
          border-bottom: 2px solid #fd1212;
        }
      }
    }
  }
</style>
