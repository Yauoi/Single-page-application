<template>
  <div class="home-page">
    <header-vue class="header-position" :class="{'header-fixed': headerStyle === 1}"></header-vue>
    
    <video id="atrvideo" src="http://vpaishe.oss-cn-beijing.aliyuncs.com/index1030.mp4" webkit-playsinline loop="loop" autoplay="autoplay" style="width: 100%; height: 100%;left: 0; top: 0;filter:alpha(opacity=70);opacity: 0.7;"></video>
    <div class="video-title">
      <img src="../../assets/icon-7.png" alt="拍视频，就找微拍摄">
      <p>全球领先的商业视频解决方案服务提供商</p>
    </div>
    <sign class="sign"></sign>
    <!-- 我们的优势 -->
    <div class="goodness">
      <img src="../../assets/icon-2.png" alt="我们的优势">
      <div class="goodness-list">
        <div class="item">
          <div class="originality"></div>
          <h4>免费无线创意</h4>
          <p>10+万资深策划编辑创意提供</p>
        </div>
        <div class="right-line"></div>
        <div class="item">
          <div class="team"></div>
          <h4>资深制作团队</h4>
          <p>6000+专业制作团队优中选优</p>
        </div>
        <div class="right-line"></div>
        <div class="item">
          <div class="safeguard"></div>
          <h4>高品质保障</h4>
          <p>低成本高品质保障费用低于行业50%</p>
        </div>
        <div class="right-line"></div>
        <div class="item">
          <div class="service"></div>
          <h4>一对一服务</h4>
          <p>视频管家一对一现场监制</p>
        </div>
      </div>
    </div>

    <!-- 我们的服务 -->
    <div class="service-component">
      <img src="../../assets/icon-3.png" alt="我们的服务">
      <p class="strong-line"></p>
      <div class="service-list">
        <div class="service-item" :class="{'service-item-bg': serviceBg === 1 }" @click="changeBG(1)">
          <img src="../../assets/icon-tv.png">
          <p>宣传片</p>
        </div>
        <div class="service-item" :class="{'service-item-bg': serviceBg === 2 }" @click="changeBG(2)">
          <img src="../../assets/icon-tv.png">
          <p>广告片</p>
        </div>
        <div class="service-item" :class="{'service-item-bg': serviceBg === 3 }" @click="changeBG(3)">
          <img src="../../assets/icon-vm.png">
          <p>微电影</p>
        </div>
        <div class="service-item" :class="{'service-item-bg': serviceBg === 4 }" @click="changeBG(4)">
          <img src="../../assets/icon-tv.png">
          <p>视频营销</p>
        </div>
        <div class="service-red-item">
          {{ serviceDes }}
        </div>
      </div>
    </div>

    <!-- 我们的推荐 -->
    <div class="recommend">
      <img src="../../assets/icon-45.png" alt="我们的推荐">
      <div class="btn-list">
        <p @click="selectRecommend(1)" :class="{'recommend-bg': recommendBg === 1}">宣传片</p>
        <p @click="selectRecommend(2)" :class="{'recommend-bg': recommendBg === 2}">广告片</p>
        <p @click="selectRecommend(4)" :class="{'recommend-bg': recommendBg === 4}">微电影</p>
        <p @click="selectRecommend(5)" :class="{'recommend-bg': recommendBg === 5}">视频营销</p>
      </div>
      <div class="video-box">
        <div class="video-list">
          <div class="video-item" v-for="(item, index) in list" :key="index">
            <div class="a-box">
              <a href="" target="_blank">
                <img :src="item.thumb_url">
                <span></span>
              </a>
            </div>
            <h4>{{ item.name }}</h4>
            <p>{{item.director_name}} / {{item.detail}}</p>
          </div>
        </div>
        
        <div class="more-video">
          <p>更多视频 <img src="../../assets/icon-_32.png" alt="more"></p>
        </div>
      </div>
    </div>

    <!-- 我们的数据 -->
    <div class="we-data">
      <img src="../../assets/icon-data.png" alt="我们的数据">
      <div class="we-data-list">
        <div class="item">
          <div class="originality"></div>
          <h4>累计发行作品3450部</h4>
          <p>Total distribution works 3450</p>
        </div>
        <div class="right-line"></div>
        <div class="item">
          <div class="team"></div>
          <h4>累计播放数量213.54亿</h4>
          <p>Thecumulative number of plays was213.54 billion</p>
        </div>
        <div class="right-line"></div>
        <div class="item">
          <div class="safeguard"></div>
          <h4>320家合作媒体同道</h4>
          <p>There are 320 co-media partners</p>
        </div>
      </div>
    </div>
    <!-- Partner and brand -->
    <div class="partner-and-brand">
      <div class="contains">
        <div class="partner">
          <img src="../../assets/icon-1111.png" alt="战略合作伙伴">
        </div>
        <div class="partner-content">
          <img src="../../assets/logo-3333.png" alt="战略合作伙伴">
        </div>
        <div class="brand">
          <img src="../../assets/icon-2222.png" alt="合作品牌">
        </div>
        <div class="brand-content">
          <img src="../../assets/logo-4444.png" alt="合作品牌">
        </div>
        <div class="photograph">
          <p>立即预约拍视频</p>
        </div>  
      </div>
    </div>
    <footer-vue></footer-vue>
  </div>
</template>

<script>
  import { mapState } from 'vuex'

  import HeaderVue from '../layout/header'
  import FooterVue from '../layout/footer'
  import Sign from '../sign_up/index'

  export default {
    name: 'home',
    components: {
      HeaderVue,
      FooterVue,
      Sign
    },
    data () {
      return {
        headerStyle: 0,
        serviceInterval: null,
        serviceBg: 1,
        recommendBg: 1,
        list: [],
        serviceDes: '企业宣传片、产品宣传片、品牌宣传片、城市类宣传片等，一站式优质服务'
      }
    },
    created () {
      // 获取视频的请求
      this.$store.dispatch('getVideoDataAction')
    },
    mounted () {
      this.setIntervalFunc()
      let _this = this
      window.onscroll = function (val) {
        let ele = document.getElementById('atrvideo')
        let mainOffsetTop = ele && ele.scrollTop
        let videoHeight = ele && ele.offsetHeight
        if (document.documentElement.scrollTop > (videoHeight + mainOffsetTop)) {
          _this.headerStyle = 1
          _this.$store.commit('LOGO_STATE', 1)
        } else {
          _this.headerStyle = 0
          _this.$store.commit('LOGO_STATE', 0)
        }
      }
    },
    computed: mapState({
      videoDatas: state => state.dataInfo.videoDatas
    }),
    watch: {
      videoDatas (res) {
        if (res && res.data && res.data.length < 1) return
        for (let i = 0, len = res.data.length; i < len; i++) {
          if (+res.data[i].id === 1) {
            this.list = res.data[i].video.slice(0, 8)
            break
          }
        }
      }
    },
    methods: {
      // 我的的服务模块的轮播图的计时器
      setIntervalFunc () {
        this.serviceInterval = setInterval(() => {
          if (this.serviceBg === 4) {
            this.serviceBg = 0
          }
          this.serviceBg += 1
          this.callServiceInterval(this.serviceBg)
        }, 4000)
      },
      // 初始化我的的服务模块的轮播图
      callServiceInterval (num) {
        switch (num) {
          case 1:
            this.serviceDes = '企业宣传片、产品宣传片、品牌宣传片、城市类宣传片等，一站式优质服务'
            break
          case 2:
            this.serviceDes = '广告片没词'
            break
          case 3:
            this.serviceDes = '微电影没词'
            break
          case 4:
            this.serviceDes = '视频营销没词'
            break
          default:
            this.serviceDes = '企业宣传片、产品宣传片、品牌宣传片、城市类宣传片等，一站式优质服务'
        }
      },
      // 手动触我的的服务模块发轮播图
      changeBG (num) {
        clearInterval(this.serviceInterval)
        this.setIntervalFunc()
        this.serviceBg = num
        switch (num) {
          case 1:
            this.serviceDes = '企业宣传片、产品宣传片、品牌宣传片、城市类宣传片等，一站式优质服务'
            break
          case 2:
            this.serviceDes = '广告片没词'
            break
          case 3:
            this.serviceDes = '微电影没词'
            break
          case 4:
            this.serviceDes = '视频营销没词'
            break
          default:
            this.serviceDes = '企业宣传片、产品宣传片、品牌宣传片、城市类宣传片等，一站式优质服务'
        }
      },
      // 切换我们的数据模块的视频内容
      selectRecommend (num) {
        this.recommendBg = num
        if (this.videoDatas && this.videoDatas.data.length < 1) return
        for (let i = 0, len = this.videoDatas.data.length; i < len; i++) {
          if (+this.videoDatas.data[i].id === num) {
            this.list = this.videoDatas.data[i] && this.videoDatas.data[i].video.slice(0, 8)
            break
          }
        }
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
@import './index';
</style>