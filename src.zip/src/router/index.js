import Vue from 'vue'
import Router from 'vue-router'
import HomePage from '../components/home_page/index'
import ServiceProcess from '../components/service_process/index'
import ContactUs from '../components/contact_us/index'
Vue.use(Router)

export const constantRouterMap = [
  {
    path: '/',
    component: HomePage,
    name: '首页'
  },
  {
    path: '/service_process',
    component: ServiceProcess,
    name: '服务流程'
  },
  {
    path: '/contact_us',
    component: ContactUs,
    name: '联系我们'
  }
]

export const asyncRouterMap = [
  // {
  //   path: '/service_process',
  //   component: ServiceProcess,
  //   name: '服务流程'
  // }
]

export default new Router({
  mode: 'history', // 后端支持可开
  // scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})
