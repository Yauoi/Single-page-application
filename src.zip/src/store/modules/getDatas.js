// 引入网络请求的api文件
import getVideoData from '../../api/getVideoData.js'
import sendcode from '../../api/sendcode.js'
import join from '../../api/join.js'

const datas = {
  state: {
    videoDatas: {},
    getCode: {},
    joinInfo: {}
  },

  mutations: {
    VIDEO_DATAS: (state, data) => {
      state.videoDatas = Object.assign({}, data)
    },
    GET_CODE: (state, data) => {
      state.getCode = Object.assign({}, data)
    },
    JOIN_INFO: (state, data) => {
      state.joinInfo = Object.assign({}, data)
    }
  },

  actions: {
    // 获取视频列表数据
    async getVideoDataAction ({commit}, params) {
      try {
        let data = await getVideoData(params)
        commit('VIDEO_DATAS', data)
      } catch (err) {
        console.log(err)
      }
    },
    // 获取验证码
    async getCodeAction ({commit}, params) {
      try {
        let data = await sendcode(params)
        commit('GET_CODE', data)
      } catch (err) {
        console.log(err)
      }
    },
    // 立即预约
    async joinAction ({commit}, params) {
      try {
        let data = await join(params)
        commit('JOIN_INFO', data)
      } catch (err) {
        console.log(err)
      }
    }
  }
}

export default datas
